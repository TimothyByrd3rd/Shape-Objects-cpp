#pragma once
/*
Timothy Byrd

This is the header file for the circle design by creating the Circle class.
*/

class Circle {

private:
	//attributes in C++
	float diameter;
	float circumference;
	float radius;
	float area;


public:
	//behaviors in C++
	//calculate the circumference
	float calculateCircumference(float diameter);//method signature for circumference calculation

	//calculate the area
	float calculateArea(float diameter);


};