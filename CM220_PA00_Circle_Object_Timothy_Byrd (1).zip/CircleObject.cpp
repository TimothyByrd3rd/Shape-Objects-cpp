// CircleObject.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
/* Timothy Byrd
Jan 13, 2020
Spring 2020

PA00 CircleObject

This program is about creating a circle object
The Circle Object has:
1) Attributes: diameter, area , radius, circumference
2) Behavior: calculates the area
			 calculates the circumference

*/
#include <iostream>
#include "Circle.h"

using namespace std;

int main()
{
	Circle c1;
	float diameter;

	cout << "Enter the value of the Circle diameter:";
	cin >> diameter;

	cout << "The circumference of the circle with " << diameter << " is: " << c1.calculateCircumference(diameter);

	return 0;



}

