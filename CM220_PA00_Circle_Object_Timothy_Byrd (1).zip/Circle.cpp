/*
Timothy Byrd

This is the Implementation of the Circle.h design
*/

#include "Circle.h"
#include<iostream>

float Circle::calculateCircumference(float d)
{
	circumference = 3.14 * d;
	return circumference;
}


float Circle::calculateArea(float d)
{
	radius = d / 2;
	area = 3.14 * radius * radius;
	return area;
}