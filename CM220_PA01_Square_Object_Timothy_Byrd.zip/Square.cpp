/*
Timothy Byrd

This is the Implementation of the Square.h design nehavio
*/

#include "Square.h"
#include<iostream>
using namespace std;

float Square::calculatePerimeter(float l)
{
	cout << "Enter the side length: ";
	cin >> l;
	length = l;
	
	perimeter = Number_of_sides * l;
	cout << "The perimeter of the Square with the side " << length << " is: " << perimeter;
	return perimeter;
}


float Square::calculateArea(float l)
{
	area = l * l ;
	return area;
}