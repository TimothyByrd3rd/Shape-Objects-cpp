#pragma once
/*
Timothy Byrd

This is the header file for the square design by creating the Square class.
*/

class Square {

private:
	//attributes in C++
	float perimeter;
	float length;
	float area;
	const int Number_of_sides = 4;


public:
	//behaviors in C++
	//calculate the perimeter
	float calculatePerimeter(float length);//method signature for perimeter calculation

	//calculate the area
	float calculateArea(float length);


};
