/* Timothy Byrd
Jan 22, 2020
Spring 2020

PA00 SquareObject

This program is about creating a circle object
The Square Object has:
1) Attributes: perimeter, area , length,
2) Behavior: calculates the area
			 calculates the circumference

*/
#include <iostream>
#include "Square.h"

using namespace std;

int main()
{

	Square mySquare; //a square object called mySquare
	Square hisSquare;
	float l = 0.0f;

	mySquare.calculatePerimeter(l);

	return 0;
	/*
	Square p1;
	float length;

	cout << "Enter the value of the Square's length:";
	cin >> length;

	cout << "The perimeter of a square with the length of " << length << " is: " << p1.calculatePerimeter(length);

	return 0;
	*/


}
